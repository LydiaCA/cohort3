import functions from "./dom-functions.js"

idShow.addEventListener("click", () => {
    let listItems = document.querySelectorAll("li");
    idMessage.textContent = functions.showItems(listItems);
});

idAdd.addEventListener("click", () => {
    functions.addItems(idOl, document.querySelectorAll("li").length);
});

idLeftPanel.addEventListener("click", () => {
    let nextCount = 0;
    if (event.target.id === "idAddCard") {
        nextCount = parseInt(functions.getCounter(idLeftPanel)) + 1;
        idLeftPanel.appendChild(functions.createCard(idLeftPanel));
    };

    if (event.target.id === "idAddBefore") {
        console.log("addBefore location", event.target.parentNode.parentNode);
        nextCount = parseInt(functions.getCounter(idLeftPanel)) + 1;
        idLeftPanel.insertBefore(functions.createCard(idLeftPanel), event.target.parentNode);
    };

    if (event.target.id === "idAddAfter") {
        nextCount = parseInt(functions.getCounter(idLeftPanel)) + 1;
        idLeftPanel.insertBefore(functions.createCard(idLeftPanel), event.target.parentNode.nextSibling);
    };

    if (event.target.id === "idDelete") {
        nextCount = parseInt(functions.getCounter(idLeftPanel)) - 1;
        console.log("event.target.parentNode ", event.target.parentNode.parentNode);
        idLeftPanel.removeChild(event.target.parentNode);
    };
});

/* 
function createButton(buttonText) {
    let buttonId = "";
    if (buttonText === "Add Before") buttonId = "idAddBefore";
    if (buttonText === "Add After") buttonId = "idAddAfter";
    if (buttonText === "Delete") buttonId = "idDelete";

    let newButton = document.createElement("button");
    newButton.setAttribute("class", "button");
    newButton.setAttribute("type", "button");
    newButton.setAttribute("id", buttonId);
    newButton.textContent = buttonText;
    console.log("newButton is: ", newButton);
    return newButton;
};

function createCard(cardNumber) {
    let newCard = document.createElement("div");
    let b = document.createElement("b");
    let title = document.createTextNode(`Card ${cardNumber}`);
    b.appendChild(title);

    newCard.setAttribute("class", "card");
    newCard.setAttribute("count", cardNumber);
    

    newCard.appendChild(document.createElement("br"));

    let p1 = document.createElement("p");
    let p2 = document.createElement("p");
    p1.appendChild(createButton("Add Before"));
    p1.appendChild(createButton("Add After"));

    newCard.appendChild(document.createElement("br"));
    p2.appendChild(createButton("Delete"));

    newCard.appendChild(b);
    newCard.appendChild(p1);
    newCard.appendChild(p2);
    console.log(newCard);
    return newCard;
};
 */



